<div style="height:50px"></div>
<footer class="footer navbar-fixed-bottom">
      <div class="container">
        <p class="text-muted">Sociedad Italiana de Pujato General Armando Díaz - Dirección: J.R. Rodríguez 448 - Pujato, Santa Fe, Argentina - Telefono: (03464)-494636</p>
		<p><a href="mapadelsitio.php">Mapa del sitio</a> - <a href="preguntasfrecuentes.php">Preguntas frecuentes</a></p>
		
      </div>
      
</footer>